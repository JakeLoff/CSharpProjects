﻿namespace EmployeeSearchDatabase
{


    partial class PersonnelDataSet
    {
    }
}

namespace EmployeeSearchDatabase.PersonnelDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
